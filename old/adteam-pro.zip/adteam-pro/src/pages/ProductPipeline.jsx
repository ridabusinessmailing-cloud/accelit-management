import { useState } from 'react'
import { useRealtimeTable } from '../hooks/useRealtimeTable.js'
import { useAuth } from '../lib/AuthContext.jsx'
import {
  C, Tag, Avatar, Card, Modal, FL, Inp, Sel, Row, Btn,
  PageHeader, THead, TR, TD, FilterBar, DriveLink,
  EmptyRow, LoadingRow, ErrorBanner, STATUS_META,
} from '../components/ui.jsx'

const TEAM = ['Rida', 'Oussama', 'Saida', 'Sana']
const PRODUCT_STATUSES = ['Pending','Approved','Rejected','In creative production','Testing','Scaling','Killed']

const blank = (user) => ({ name: '', product_link: '', supplier: '', added_by: user, validation_status: 'Pending' })

export default function ProductPipeline() {
  const { userName, isAdmin } = useAuth()
  const { rows, loading, error, insert, update, remove } = useRealtimeTable('products', { orderBy: 'created_at', ascending: false })

  const [modal, setModal]   = useState(false)
  const [editing, setEditing] = useState(null)
  const [fStatus, setFStatus] = useState('')
  const [form, setForm]     = useState(blank(userName))
  const [saving, setSaving] = useState(false)
  const [err, setErr]       = useState('')

  function openNew()  { setForm(blank(userName)); setEditing(null); setErr(''); setModal(true) }
  function openEdit(r) { setForm({ name: r.name, product_link: r.product_link || '', supplier: r.supplier || '', added_by: r.added_by, validation_status: r.validation_status }); setEditing(r.id); setErr(''); setModal(true) }

  async function save() {
    if (!form.name.trim()) return setErr('Product name is required.')
    setSaving(true); setErr('')
    try {
      if (editing) await update(editing, form)
      else await insert(form)
      setModal(false)
    } catch (e) { setErr(e.message) }
    setSaving(false)
  }

  async function setStatus(id, validation_status) {
    if (!isAdmin) return alert('Only admins (Rida & Oussama) can change product status.')
    try { await update(id, { validation_status }) } catch (e) { alert(e.message) }
  }

  async function del(id) {
    if (!isAdmin) return alert('Only admins can delete products.')
    if (!confirm('Delete this product?')) return
    try { await remove(id) } catch (e) { alert(e.message) }
  }

  const F = fStatus ? rows.filter(r => r.validation_status === fStatus) : rows
  const counts = PRODUCT_STATUSES.map(s => ({ s, n: rows.filter(r => r.validation_status === s).length }))

  return (
    <div>
      <PageHeader title="🧪 Product Pipeline" subtitle="Track products from sourcing to scaling"
        action={<Btn onClick={openNew}>+ Add Product</Btn>} />
      {error && <ErrorBanner message={error} />}

      {/* Pipeline status bar */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 20, overflowX: 'auto', paddingBottom: 4 }}>
        {counts.map(({ s, n }) => (
          <div key={s} onClick={() => setFStatus(fStatus === s ? '' : s)}
            style={{ flexShrink: 0, cursor: 'pointer', background: fStatus === s ? STATUS_META[s]?.bg || '#F0EDE8' : C.surface, border: `1.5px solid ${fStatus === s ? STATUS_META[s]?.text || '#9B9589' : C.border}`, borderRadius: 10, padding: '8px 14px', textAlign: 'center' }}>
            <div style={{ fontSize: 20, fontWeight: 900, color: STATUS_META[s]?.text || C.textMid }}>{n}</div>
            <div style={{ fontSize: 11, color: C.textLight, fontWeight: 600 }}>{s}</div>
          </div>
        ))}
      </div>

      <Card>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <THead cols={['Product', 'Supplier', 'Added By', 'Status', 'Link', '']} />
          <tbody>
            {loading && <LoadingRow cols={6} />}
            {!loading && F.map((r, i) => (
              <TR key={r.id} alt={i % 2}>
                <TD><span style={{ fontWeight: 700 }}>{r.name}</span></TD>
                <TD><span style={{ color: C.textMid }}>{r.supplier}</span></TD>
                <TD><div style={{ display: 'flex', alignItems: 'center', gap: 7 }}><Avatar name={r.added_by} size={24} /><span style={{ fontSize: 12.5 }}>{r.added_by}</span></div></TD>
                <TD><Tag label={r.validation_status} /></TD>
                <TD><DriveLink href={r.product_link} label="View" /></TD>
                <TD>
                  <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap' }}>
                    {isAdmin && r.validation_status === 'Pending' && <>
                      <Btn sm variant="success" onClick={() => setStatus(r.id, 'Approved')}>✓ Approve</Btn>
                      <Btn sm variant="danger"  onClick={() => setStatus(r.id, 'Rejected')}>✗ Reject</Btn>
                    </>}
                    {isAdmin && r.validation_status !== 'Pending' && (
                      <select value={r.validation_status} onChange={e => setStatus(r.id, e.target.value)}
                        style={{ padding: '4px 8px', borderRadius: 7, border: `1.5px solid ${C.border}`, fontSize: 11.5, background: C.bg, fontFamily: 'inherit', cursor: 'pointer' }}>
                        {PRODUCT_STATUSES.map(s => <option key={s}>{s}</option>)}
                      </select>
                    )}
                    <Btn sm variant="ghost" onClick={() => openEdit(r)}>Edit</Btn>
                    {isAdmin && <Btn sm variant="danger" onClick={() => del(r.id)}>Del</Btn>}
                  </div>
                </TD>
              </TR>
            ))}
            {!loading && F.length === 0 && <EmptyRow cols={6} msg="No products match this filter." />}
          </tbody>
        </table>
      </Card>

      {modal && (
        <Modal title={editing ? 'Edit Product' : 'New Product'} onClose={() => setModal(false)}>
          {err && <ErrorBanner message={err} />}
          <FL label="Product Name"><Inp value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="e.g. Posture Corrector X200" /></FL>
          <FL label="Product Link"><Inp value={form.product_link} onChange={e => setForm({ ...form, product_link: e.target.value })} placeholder="https://aliexpress.com/..." /></FL>
          <Row>
            <FL label="Supplier" half><Inp value={form.supplier} onChange={e => setForm({ ...form, supplier: e.target.value })} placeholder="AliExpress, CJ…" /></FL>
            <FL label="Added By" half><Sel value={form.added_by} onChange={e => setForm({ ...form, added_by: e.target.value })}>{TEAM.map(m => <option key={m}>{m}</option>)}</Sel></FL>
          </Row>
          {isAdmin && (
            <FL label="Status">
              <Sel value={form.validation_status} onChange={e => setForm({ ...form, validation_status: e.target.value })}>
                {PRODUCT_STATUSES.map(s => <option key={s}>{s}</option>)}
              </Sel>
            </FL>
          )}
          <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 8 }}>
            <Btn variant="ghost" onClick={() => setModal(false)}>Cancel</Btn>
            <Btn onClick={save} disabled={saving}>{saving ? 'Saving…' : 'Save Product'}</Btn>
          </div>
        </Modal>
      )}
    </div>
  )
}
