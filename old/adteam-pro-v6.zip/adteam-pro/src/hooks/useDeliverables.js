/**
 * useDeliverables
 *
 * Central hub for all "task ↔ product asset" logic.
 * Nothing else in the codebase touches product_assets directly.
 *
 * ── Public exports ────────────────────────────────────────────────────────────
 *
 *  ASSET_TYPES          Full ordered catalogue of all 7 asset types.
 *  DELIVERABLE_CONFIG   Backward-compat: subset driven by Saida's workflow tasks.
 *  getDeliverableConfig(taskTitle)
 *  validateDeliverable(taskTitle, deliverableUrl)
 *  saveDeliverableAsset(productName, taskTitle, deliverableUrl)
 *  ensureAssetRow(productName)   — create empty row on task creation
 *  upsertAssetField(productName, dbColumn, url)  — used by Assets page
 */

import { supabase } from '../lib/supabase.js'

// ── Full asset type catalogue ─────────────────────────────────────────────────
export const ASSET_TYPES = [
  {
    key:             'landing_page',
    label:           'Landing Page',
    icon:            '🌐',
    dbColumn:        'landing_page_url',
    placeholder:     'https://yourstore.com/product-page',
    taskTitlePrefix: 'Create landing page for ',
  },
  {
    key:             'video_creatives',
    label:           'Video Creatives',
    icon:            '🎬',
    dbColumn:        'creatives_drive_url',
    placeholder:     'https://drive.google.com/drive/folders/…',
    taskTitlePrefix: 'Create 4 video creatives for ',
  },
  {
    key:             'static_images',
    label:           'Static Images',
    icon:            '🖼️',
    dbColumn:        'images_drive_url',
    placeholder:     'https://drive.google.com/file/d/…',
    taskTitlePrefix: 'Create 1 static image for ',
  },
  {
    key:             'ugc_videos',
    label:           'UGC Videos',
    icon:            '🎥',
    dbColumn:        'ugc_videos_url',
    placeholder:     'https://drive.google.com/drive/folders/…',
    taskTitlePrefix: null,
  },
  {
    key:             'ad_hooks',
    label:           'Ad Hooks',
    icon:            '🪝',
    dbColumn:        'ad_hooks_url',
    placeholder:     'https://docs.google.com/… or https://notion.so/…',
    taskTitlePrefix: null,
  },
  {
    key:             'ad_copies',
    label:           'Ad Copies',
    icon:            '✍️',
    dbColumn:        'ad_copies_url',
    placeholder:     'https://docs.google.com/… or https://notion.so/…',
    taskTitlePrefix: null,
  },
  {
    key:             'documentation',
    label:           'Product Documentation',
    icon:            '📄',
    dbColumn:        'product_documentation_url',
    placeholder:     'PDF link, Google Drive, or Notion page URL',
    taskTitlePrefix: null,
  },
]

// ── DELIVERABLE_CONFIG — backward-compat for TaskManager ─────────────────────
const DELIVERABLE_CONFIGS = ASSET_TYPES.filter(a => a.taskTitlePrefix)

export const DELIVERABLE_CONFIG = Object.fromEntries(
  DELIVERABLE_CONFIGS.map(a => [a.key, {
    titlePrefix:  a.taskTitlePrefix,
    field:        a.dbColumn,
    label:        a.label,
    placeholder:  a.placeholder,
    assetSection: a.label,
    icon:         a.icon,
    hint:         'Required before marking this task as Done.',
  }])
)

// ── getDeliverableConfig ──────────────────────────────────────────────────────
export function getDeliverableConfig(taskTitle) {
  if (!taskTitle) return null
  const at = DELIVERABLE_CONFIGS.find(a => taskTitle.startsWith(a.taskTitlePrefix))
  if (!at) return null
  return {
    titlePrefix:  at.taskTitlePrefix,
    field:        at.dbColumn,
    label:        at.label,
    placeholder:  at.placeholder,
    assetSection: at.label,
    icon:         at.icon,
    hint:         'Required before marking this task as Done.',
  }
}

// ── validateDeliverable ───────────────────────────────────────────────────────
export function validateDeliverable(taskTitle, deliverableUrl) {
  const config = getDeliverableConfig(taskTitle)
  if (!config) return null
  if (!deliverableUrl || !deliverableUrl.trim()) {
    return `"${config.label}" is required before marking this task as Done.`
  }
  return null
}

// ── saveDeliverableAsset ──────────────────────────────────────────────────────
export async function saveDeliverableAsset(productName, taskTitle, deliverableUrl) {
  if (!productName || !deliverableUrl?.trim()) return
  const config = getDeliverableConfig(taskTitle)
  if (!config) return
  const { error } = await supabase
    .from('product_assets')
    .upsert({ product_name: productName, [config.field]: deliverableUrl.trim() }, { onConflict: 'product_name' })
  if (error) {
    console.warn('[Deliverables] saveDeliverableAsset failed:', error.message)
    throw error
  }
}

// ── ensureAssetRow ────────────────────────────────────────────────────────────
export async function ensureAssetRow(productName) {
  if (!productName?.trim()) return
  const { error } = await supabase
    .from('product_assets')
    .upsert({ product_name: productName.trim() }, { onConflict: 'product_name', ignoreDuplicates: true })
  if (error) console.warn('[Deliverables] ensureAssetRow failed:', error.message)
}

// ── upsertAssetField ──────────────────────────────────────────────────────────
export async function upsertAssetField(productName, dbColumn, url) {
  if (!productName?.trim()) return
  const { error } = await supabase
    .from('product_assets')
    .upsert({ product_name: productName.trim(), [dbColumn]: url || null }, { onConflict: 'product_name' })
  if (error) {
    console.warn('[Deliverables] upsertAssetField failed:', error.message)
    throw error
  }
}
