import { useState, useMemo } from 'react'
import { useRealtimeTable } from '../hooks/useRealtimeTable.js'
import { C, Modal, Spinner } from '../components/ui.jsx'
import { ASSET_TYPES, upsertAssetField, ensureAssetRow } from '../hooks/useDeliverables.js'

// ── Helpers ───────────────────────────────────────────────────────────────────
function isValidUrl(s) {
  if (!s) return false
  try { new URL(s); return true } catch { return false }
}

function linkLabel(url) {
  if (!url) return null
  try {
    const u = new URL(url)
    if (u.hostname.includes('drive.google.com')) return 'Open Drive'
    if (u.hostname.includes('docs.google.com'))  return 'Open Doc'
    if (u.hostname.includes('notion.so'))        return 'Open Notion'
    if (u.hostname.includes('docs.google'))      return 'Open Sheets'
    if (url.endsWith('.pdf'))                    return 'Open PDF'
    return 'Open Link'
  } catch { return 'Open Link' }
}

// ── Status badge ──────────────────────────────────────────────────────────────
function StatusBadge({ uploaded }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      fontSize: 11, fontWeight: 700, padding: '2px 9px', borderRadius: 20,
      background: uploaded ? '#EBF7F1' : '#F0EDE8',
      color:      uploaded ? '#1E7B4B' : '#9B9589',
    }}>
      <span style={{ width: 5, height: 5, borderRadius: '50%', background: uploaded ? '#1E7B4B' : '#C8C3BC' }} />
      {uploaded ? 'Uploaded' : 'Pending'}
    </span>
  )
}

// ── Inline link button ────────────────────────────────────────────────────────
function LinkButton({ url }) {
  if (!url || !isValidUrl(url)) return null
  return (
    <a href={url} target="_blank" rel="noreferrer" style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      fontSize: 12, fontWeight: 600, padding: '4px 10px', borderRadius: 7,
      background: '#EEF4FD', color: '#1A5FB4',
      textDecoration: 'none', border: '1px solid #1A5FB422',
      whiteSpace: 'nowrap', flexShrink: 0,
    }}>
      ↗ {linkLabel(url)}
    </a>
  )
}

// ── Edit Link Modal ───────────────────────────────────────────────────────────
function EditLinkModal({ assetType, productName, currentUrl, onSave, onClose }) {
  const [url, setUrl]     = useState(currentUrl || '')
  const [saving, setSaving] = useState(false)
  const [err, setErr]     = useState('')

  async function save() {
    const trimmed = url.trim()
    if (trimmed && !isValidUrl(trimmed)) {
      setErr('Please enter a valid URL (must start with https://)')
      return
    }
    setSaving(true); setErr('')
    try {
      await upsertAssetField(productName, assetType.dbColumn, trimmed)
      onSave(trimmed)
      onClose()
    } catch (e) {
      setErr(e.message || 'Failed to save. Please try again.')
    }
    setSaving(false)
  }

  function onKey(e) {
    if (e.key === 'Enter') save()
    if (e.key === 'Escape') onClose()
  }

  return (
    <Modal title={`${assetType.icon} ${assetType.label}`} onClose={onClose}>
      <div style={{ marginBottom: 8, fontSize: 13, color: C.textMid }}>
        Product: <strong style={{ color: C.text }}>{productName}</strong>
      </div>

      {err && (
        <div style={{ background: '#FDECEA', border: '1.5px solid #F5C6C2', borderRadius: 8, padding: '10px 14px', marginBottom: 14, color: '#C0392B', fontSize: 13 }}>
          ⚠️ {err}
        </div>
      )}

      <div style={{ marginBottom: 6 }}>
        <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: C.textLight, marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.07em' }}>
          Resource URL
        </label>
        <input
          type="url"
          value={url}
          onChange={e => { setUrl(e.target.value); setErr('') }}
          onKeyDown={onKey}
          placeholder={assetType.placeholder}
          autoFocus
          style={{
            width: '100%', padding: '10px 12px', borderRadius: 9, boxSizing: 'border-box',
            border: `1.5px solid ${C.border}`, fontSize: 13.5, color: C.text,
            background: C.bg, outline: 'none', fontFamily: 'inherit',
          }}
          onFocus={e => e.target.style.borderColor = C.accent}
          onBlur={e => e.target.style.borderColor = C.border}
        />
        <div style={{ fontSize: 11.5, color: C.textLight, marginTop: 5 }}>
          Accepts Google Drive, Notion, PDF, or any URL. Leave blank to clear.
        </div>
      </div>

      <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 20 }}>
        <button onClick={onClose} style={{
          background: 'transparent', color: C.textMid,
          border: `1.5px solid ${C.border}`, borderRadius: 8,
          padding: '9px 18px', fontSize: 13.5, fontWeight: 700,
          cursor: 'pointer', fontFamily: 'inherit',
        }}>
          Cancel
        </button>
        <button onClick={save} disabled={saving} style={{
          background: saving ? C.textLight : C.text, color: '#fff', border: 'none',
          borderRadius: 8, padding: '9px 18px', fontSize: 13.5, fontWeight: 700,
          cursor: saving ? 'not-allowed' : 'pointer', fontFamily: 'inherit',
        }}>
          {saving ? 'Saving…' : currentUrl ? 'Update Link' : 'Save Link'}
        </button>
      </div>
    </Modal>
  )
}

// ── Asset Row ─────────────────────────────────────────────────────────────────
function AssetRow({ assetType, url, productName, onUpdated, isLast }) {
  const [editing, setEditing] = useState(false)
  const uploaded = !!(url && isValidUrl(url))

  return (
    <>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 12,
        padding: '11px 0',
        borderBottom: isLast ? 'none' : `1px solid ${C.borderLight}`,
      }}>
        {/* Icon + label */}
        <span style={{ fontSize: 16, flexShrink: 0, width: 22, textAlign: 'center' }}>{assetType.icon}</span>
        <span style={{ fontSize: 13, fontWeight: 600, color: C.text, flex: 1, minWidth: 0 }}>
          {assetType.label}
        </span>

        {/* Status */}
        <StatusBadge uploaded={uploaded} />

        {/* Actions */}
        <div style={{ display: 'flex', gap: 6, alignItems: 'center', flexShrink: 0 }}>
          {uploaded && <LinkButton url={url} />}
          <button
            onClick={() => setEditing(true)}
            style={{
              background: uploaded ? C.bg : C.accent,
              color: uploaded ? C.textMid : '#fff',
              border: uploaded ? `1.5px solid ${C.border}` : 'none',
              borderRadius: 7, padding: '4px 12px', fontSize: 12, fontWeight: 700,
              cursor: 'pointer', fontFamily: 'inherit', whiteSpace: 'nowrap',
            }}
          >
            {uploaded ? 'Edit' : '+ Add link'}
          </button>
        </div>
      </div>

      {editing && (
        <EditLinkModal
          assetType={assetType}
          productName={productName}
          currentUrl={url}
          onSave={newUrl => onUpdated(assetType.dbColumn, newUrl)}
          onClose={() => setEditing(false)}
        />
      )}
    </>
  )
}

// ── Product Card ──────────────────────────────────────────────────────────────
function ProductCard({ product, assetRow, tasks }) {
  // Local optimistic state so UI updates instantly on save
  const [localAssets, setLocalAssets] = useState({})

  function handleUpdated(dbColumn, newUrl) {
    setLocalAssets(prev => ({ ...prev, [dbColumn]: newUrl }))
  }

  // Merge: local optimistic overrides DB row
  const merged = { ...(assetRow || {}), ...localAssets }

  // Count uploaded assets
  const uploadedCount = ASSET_TYPES.filter(at => {
    const url = merged[at.dbColumn]
    return url && isValidUrl(url)
  }).length

  // Find linked tasks for this product (for the "tasks" indicator)
  const productTasks = tasks.filter(t =>
    t.related_product === product.name ||
    t.related_product === (assetRow?.product_name)
  )
  const openTasks   = productTasks.filter(t => !t.completed).length
  const doneTasks   = productTasks.filter(t =>  t.completed).length

  return (
    <div style={{
      background: C.surface, borderRadius: 16,
      border: `1.5px solid ${C.border}`,
      overflow: 'hidden',
      boxShadow: '0 1px 4px #1A171408',
    }}>
      {/* Card header */}
      <div style={{
        padding: '16px 20px 14px',
        borderBottom: `1px solid ${C.borderLight}`,
        background: '#FAFAF8',
      }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 10 }}>
          <div style={{ minWidth: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
              <span style={{ fontSize: 15, fontWeight: 800, color: C.text }}>{product.name}</span>
              {product.sku && (
                <span style={{ fontSize: 11, color: C.textLight, background: C.border, padding: '1px 8px', borderRadius: 6, fontWeight: 600 }}>
                  {product.sku}
                </span>
              )}
              {/* Product status pill */}
              <span style={{
                fontSize: 11, fontWeight: 700, padding: '1px 9px', borderRadius: 20,
                background: product.status === 'active' ? '#EBF7F1' : '#FDF6E3',
                color:      product.status === 'active' ? '#1E7B4B'  : '#B07D1A',
              }}>
                {product.status}
              </span>
            </div>
            {/* Task summary */}
            {productTasks.length > 0 && (
              <div style={{ fontSize: 11.5, color: C.textLight, marginTop: 4, display: 'flex', gap: 10 }}>
                {openTasks > 0 && <span>🔄 {openTasks} task{openTasks !== 1 ? 's' : ''} open</span>}
                {doneTasks > 0 && <span>✅ {doneTasks} done</span>}
              </div>
            )}
          </div>

          {/* Asset completion badge */}
          <div style={{ flexShrink: 0, textAlign: 'right' }}>
            <div style={{ fontSize: 20, fontWeight: 900, color: uploadedCount === ASSET_TYPES.length ? '#1E7B4B' : C.textMid, lineHeight: 1 }}>
              {uploadedCount}/{ASSET_TYPES.length}
            </div>
            <div style={{ fontSize: 10.5, color: C.textLight, marginTop: 1 }}>assets</div>
          </div>
        </div>

        {/* Progress bar */}
        <div style={{ marginTop: 12, height: 4, background: C.borderLight, borderRadius: 4, overflow: 'hidden' }}>
          <div style={{
            height: '100%', borderRadius: 4,
            width: `${(uploadedCount / ASSET_TYPES.length) * 100}%`,
            background: uploadedCount === ASSET_TYPES.length ? '#1E7B4B' : C.accent,
            transition: 'width 0.3s ease',
          }} />
        </div>
      </div>

      {/* Asset rows */}
      <div style={{ padding: '4px 20px 8px' }}>
        {ASSET_TYPES.map((at, idx) => (
          <AssetRow
            key={at.key}
            assetType={at}
            url={merged[at.dbColumn]}
            productName={product.name}
            onUpdated={handleUpdated}
            isLast={idx === ASSET_TYPES.length - 1}
          />
        ))}
      </div>
    </div>
  )
}

// ── Add Product Modal ─────────────────────────────────────────────────────────
function AddProductModal({ existingNames, onAdd, onClose }) {
  const [name, setName]     = useState('')
  const [saving, setSaving] = useState(false)
  const [err, setErr]       = useState('')

  async function save() {
    const n = name.trim()
    if (!n) return setErr('Product name is required.')
    if (existingNames.includes(n)) return setErr('A product with this name already exists.')
    setSaving(true); setErr('')
    try {
      await ensureAssetRow(n)
      onAdd(n)
      onClose()
    } catch (e) { setErr(e.message) }
    setSaving(false)
  }

  return (
    <Modal title="Add Product to Assets" onClose={onClose}>
      {err && (
        <div style={{ background: '#FDECEA', border: '1.5px solid #F5C6C2', borderRadius: 8, padding: '10px 14px', marginBottom: 14, color: '#C0392B', fontSize: 13 }}>
          ⚠️ {err}
        </div>
      )}
      <div style={{ marginBottom: 6 }}>
        <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: C.textLight, marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.07em' }}>
          Product Name
        </label>
        <input
          type="text"
          value={name}
          onChange={e => { setName(e.target.value); setErr('') }}
          onKeyDown={e => { if (e.key === 'Enter') save(); if (e.key === 'Escape') onClose() }}
          placeholder="e.g. Skin Serum Pro"
          autoFocus
          style={{
            width: '100%', padding: '10px 12px', borderRadius: 9, boxSizing: 'border-box',
            border: `1.5px solid ${C.border}`, fontSize: 13.5, color: C.text,
            background: C.bg, outline: 'none', fontFamily: 'inherit',
          }}
          onFocus={e => e.target.style.borderColor = C.accent}
          onBlur={e => e.target.style.borderColor = C.border}
        />
        <div style={{ fontSize: 11.5, color: C.textLight, marginTop: 5 }}>
          Must match the product name used in tasks.
        </div>
      </div>
      <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 20 }}>
        <button onClick={onClose} style={{ background: 'transparent', color: C.textMid, border: `1.5px solid ${C.border}`, borderRadius: 8, padding: '9px 18px', fontSize: 13.5, fontWeight: 700, cursor: 'pointer', fontFamily: 'inherit' }}>
          Cancel
        </button>
        <button onClick={save} disabled={saving} style={{ background: saving ? C.textLight : C.text, color: '#fff', border: 'none', borderRadius: 8, padding: '9px 18px', fontSize: 13.5, fontWeight: 700, cursor: saving ? 'not-allowed' : 'pointer', fontFamily: 'inherit' }}>
          {saving ? 'Creating…' : 'Create'}
        </button>
      </div>
    </Modal>
  )
}

// ── Main page ─────────────────────────────────────────────────────────────────
export default function ProductAssetsPage() {
  const { rows: products, loading: pLoading } = useRealtimeTable('products', { orderBy: 'created_at', ascending: false })
  const { rows: assets,   loading: aLoading } = useRealtimeTable('product_assets', { orderBy: 'product_name', ascending: true })
  const { rows: tasks }                        = useRealtimeTable('tasks', { orderBy: 'created_at', ascending: true })

  const [search,    setSearch]    = useState('')
  const [fStatus,   setFStatus]   = useState('')    // 'all' | 'complete' | 'pending'
  const [addModal,  setAddModal]  = useState(false)

  const loading = pLoading || aLoading

  // Build a lookup: product_name → asset row
  const assetMap = useMemo(() => {
    const m = {}
    assets.forEach(a => { m[a.product_name] = a })
    return m
  }, [assets])

  // Merge: show all products from the products table,
  // plus any asset rows that exist for names not in the products table
  // (created manually or via task automation)
  const allProductNames = useMemo(() => {
    const fromProducts = products.map(p => p.name)
    const fromAssets   = assets.map(a => a.product_name).filter(n => !fromProducts.includes(n))
    return [...fromProducts, ...fromAssets]
  }, [products, assets])

  // Filter
  const filtered = useMemo(() => {
    let names = allProductNames

    if (search) {
      const q = search.toLowerCase()
      names = names.filter(n => n.toLowerCase().includes(q))
    }

    if (fStatus === 'complete') {
      names = names.filter(n => {
        const a = assetMap[n] || {}
        return ASSET_TYPES.every(at => a[at.dbColumn] && isValidUrl(a[at.dbColumn]))
      })
    } else if (fStatus === 'pending') {
      names = names.filter(n => {
        const a = assetMap[n] || {}
        return ASSET_TYPES.some(at => !a[at.dbColumn] || !isValidUrl(a[at.dbColumn]))
      })
    }

    return names
  }, [allProductNames, assetMap, search, fStatus])

  // Summary stats
  const totalAssets    = allProductNames.length * ASSET_TYPES.length
  const uploadedAssets = assets.reduce((sum, a) =>
    sum + ASSET_TYPES.filter(at => a[at.dbColumn] && isValidUrl(a[at.dbColumn])).length, 0)
  const pctComplete    = totalAssets > 0 ? Math.round((uploadedAssets / totalAssets) * 100) : 0

  const ctrlStyle = {
    padding: '7px 12px', borderRadius: 8, border: `1.5px solid ${C.border}`,
    fontSize: 13, background: C.surface, color: C.text,
    fontFamily: 'inherit', outline: 'none', cursor: 'pointer',
  }

  return (
    <div>
      {/* ── Page header ──────────────────────────────────────────────────── */}
      <div style={{ marginBottom: 24 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
          <div>
            <h2 style={{ margin: 0, fontSize: 22, fontWeight: 800, color: C.text, letterSpacing: '-0.03em' }}>
              🗂️ Product Assets
            </h2>
            <p style={{ margin: '3px 0 0', color: C.textLight, fontSize: 13 }}>
              Creative deliverables per product — accessible to all team members
            </p>
          </div>
          <button onClick={() => setAddModal(true)} style={{
            background: C.text, color: '#fff', border: 'none', borderRadius: 9,
            padding: '9px 18px', fontSize: 13.5, fontWeight: 700,
            cursor: 'pointer', fontFamily: 'inherit',
            display: 'flex', alignItems: 'center', gap: 6,
          }}>
            + Add Product
          </button>
        </div>

        {/* Stats row */}
        <div style={{ display: 'flex', gap: 20, marginBottom: 16, flexWrap: 'wrap' }}>
          {[
            { label: 'Products tracked', value: allProductNames.length, color: C.text },
            { label: 'Assets uploaded',  value: `${uploadedAssets}/${totalAssets}`, color: C.accent },
            { label: 'Completion',        value: `${pctComplete}%`, color: pctComplete === 100 ? C.green : C.yellow },
          ].map(s => (
            <div key={s.label} style={{ background: C.surface, border: `1.5px solid ${C.border}`, borderRadius: 10, padding: '10px 16px', minWidth: 120 }}>
              <div style={{ fontSize: 20, fontWeight: 900, color: s.color, letterSpacing: '-0.03em' }}>{s.value}</div>
              <div style={{ fontSize: 11.5, color: C.textLight, fontWeight: 600, marginTop: 1 }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Filter bar */}
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
          {/* Search */}
          <div style={{ position: 'relative', flex: '1 1 180px', maxWidth: 260 }}>
            <span style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', fontSize: 14, color: C.textLight, pointerEvents: 'none' }}>🔍</span>
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search products…"
              style={{ ...ctrlStyle, width: '100%', paddingLeft: 32, boxSizing: 'border-box' }}
            />
          </div>

          {/* Status filter */}
          {[
            { v: '',         label: 'All Products' },
            { v: 'pending',  label: '⏳ Has Pending' },
            { v: 'complete', label: '✅ Complete' },
          ].map(({ v, label }) => (
            <button key={v} onClick={() => setFStatus(v)} style={{
              ...ctrlStyle,
              fontWeight: fStatus === v ? 700 : 500,
              background: fStatus === v ? C.text : C.surface,
              color: fStatus === v ? '#fff' : C.textMid,
              border: fStatus === v ? 'none' : `1.5px solid ${C.border}`,
            }}>
              {label}
            </button>
          ))}

          <span style={{ marginLeft: 'auto', fontSize: 12, color: C.textLight }}>
            {filtered.length} product{filtered.length !== 1 ? 's' : ''}
          </span>
        </div>
      </div>

      {/* ── Loading ───────────────────────────────────────────────────────── */}
      {loading && (
        <div style={{ display: 'flex', justifyContent: 'center', padding: '60px 0' }}>
          <Spinner />
        </div>
      )}

      {/* ── Empty state ───────────────────────────────────────────────────── */}
      {!loading && filtered.length === 0 && (
        <div style={{ textAlign: 'center', padding: '60px 20px' }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>🗂️</div>
          <div style={{ fontSize: 15, fontWeight: 700, color: C.textMid, marginBottom: 6 }}>
            {search || fStatus ? 'No products match your filters' : 'No products yet'}
          </div>
          <div style={{ fontSize: 13, color: C.textLight }}>
            {search || fStatus
              ? 'Try clearing the filters'
              : 'Products appear automatically when tasks are created. Or click "+ Add Product" to add manually.'}
          </div>
        </div>
      )}

      {/* ── Product cards grid ────────────────────────────────────────────── */}
      {!loading && filtered.length > 0 && (
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(380px, 1fr))',
          gap: 20,
        }}>
          {filtered.map(name => {
            const product  = products.find(p => p.name === name) || { name, id: name, status: 'test' }
            const assetRow = assetMap[name]
            return (
              <ProductCard
                key={name}
                product={product}
                assetRow={assetRow}
                tasks={tasks}
              />
            )
          })}
        </div>
      )}

      {/* ── Add product modal ─────────────────────────────────────────────── */}
      {addModal && (
        <AddProductModal
          existingNames={allProductNames}
          onAdd={() => {}}
          onClose={() => setAddModal(false)}
        />
      )}
    </div>
  )
}
